<?php
session_start();
if ($_SESSION['logged_on_user'] !== 0)
{
	if ($_SESSION['logged_on_user'] == "")
		echo "ERROR\n";
	else
		{
			echo $_SESSION['logged_on_user'];
			echo "\n";
		}
	}
	else
		echo "ERROR\n";
?>
