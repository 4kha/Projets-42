<?php
function auth($login, $passwd)
{
	$modify = FALSE;
	$pwd = hash("whirlpool", $passwd);
	$array = file_get_contents("../private/passwd");
	$test = unserialize($array);
	foreach ($test as $elem) 
	{
		if ($elem['login'] === $login && $pwd === $elem['passwd'])
			$modify = TRUE;
	}
	if ($modify == FALSE)
		return (FALSE);
	else
		return (TRUE);
}
?>
