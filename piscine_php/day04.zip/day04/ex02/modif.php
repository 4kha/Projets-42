<?php
	if ($_POST["submit"] == "OK")
	{
		if ($_POST["newpw"] == "")
		{
			echo "ERROR\n";
		}
		else
		{
			$modify = FALSE;
			$pwd = hash('whirlpool', $_POST['newpw']);
			$oldpwd = hash("whirlpool", $_POST['oldpw']);
			$array = file_get_contents("../private/passwd");
			$tmp = unserialize($array);
			$i = 0;
			foreach ($tmp as $elem)
			{
				if ($elem['login'] == $_POST['login'] && $oldpwd == $elem['passwd'])
				{
					$tmp[$i]['passwd'] = $pwd;
					$modify = TRUE;
				}
				$i++;
			}
			if ($modify == TRUE)
			{
				$serial = serialize($tmp);
				file_put_contents("../private/passwd", $serial);
				echo "OK\n";
			}
			else
				echo "ERROR\n";
		}
	}
?>
