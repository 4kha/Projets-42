<?php
session_start();
?>
<html>
  <?php include("header.php");?>
  <body>
    <center><div style="font-size:25px;">Bienvenue sur Rent A Cat, le seul site vendeur de BitCat</h1></center>
    <img style="width:100%;" src="/img/cat_automn.jpg">
    <div style="text-align:justify;font-size:20px;"> Qu'est-ce que le BitCat, c'est la seule monnaie dont la valeur depend
     du temps d'indecision d'un chat pour traverser une porte. Ce chat en question
    est bien evidement le très celebre Norminet, le seul professeur en patience
    et de distribution de BitTig de 42.
    <br/><br/>
    Ainsi donc, vous pourrez suivre ce chat dans tout l'ecole tout en suivant
  le cours du BitCat.

</div>
  </body>
</div>
  <?php include("footer.php");?>
</html>
