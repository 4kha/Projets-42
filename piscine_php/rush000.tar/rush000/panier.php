<?php
session_start();
  if ($_POST[panier] !== 0)
    $inventory = $_POST[panier];
  $article1 = array("img"=>"https://68.media.tumblr.com/dc20281ddeb7c96fb9080901bfc33652/tumblr_p420z003Md1qhy6c9o1_1280.gif", "desc"=>"I like", "price"=>"4.5", "name"=>"test", "quantite"=>"2");
  $article2 = array("img"=>"https://i.pinimg.com/originals/24/f5/1c/24f51c44063429fb51d5f39257fca188.jpg", "desc"=>"Ice cream", "price"=>"4.5", "name"=>"test", "quantite"=>"2");
  $article3 = array("img"=>"http://38.media.tumblr.com/952b534db2ede6fcf55f2d6e99e7305c/tumblr_njr0p8MKwU1qhy6c9o1_500.gif", "desc"=>"Rondoudoud", "price"=>"4.5", "name"=>"test", "quantite"=>"2");
  $article4 = array("img"=>"https://i.pinimg.com/originals/e4/c2/34/e4c234002c183c759983da21279ef93e.gif", "desc"=>"valentine", "price"=>"4.5", "name"=>"test", "quantite"=>"2");

  $inventory = array("Chat mignon"=>$article1, "chat glace"=>$article2,
   "chat valentin"=>$article3, "chat rose"=>$article4);
?>
<html>
  <?php include("header.php");?>
  <body>
<br/>
<center>
<div style="font-size:30px;">Dans le panier :<br/>
<?php foreach ($inventory as $elem)
{
  $result = $elem[quantite] * $elem[price];
    echo "<div>$elem[quantite] $elem[name]  x  $elem[price]$ = $result$</div>";
  $end = $result + $end;
}
echo "<div style=\"margin-left:30;\">total = $end$</div>";
?>
</div>
<input class="finish" type="submit" name="Payer" value="Payer"></center>
  </body>
  <br/>
</div>
  <?php include("footer.php");?>
</html>
