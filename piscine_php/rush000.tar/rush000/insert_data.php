<?php 
	session_start();
	if (!isset($_SESSION['logged_on_user']) || !isset($_POST['name'])|| !isset($_POST['image'])|| !isset($_POST['price']) || !isset($_POST['description']) ||$_POST['name'] == "" || $_POST['image'] == ""|| $_POST['price'] == "0" || $_POST['description'] == "" || !isset($_POST['submit']) || $_POST['submit'] !== 'OK'|| $_SESSION['logged_on_user'] == "")
		{
			echo "ERROR\n";
			exit;
		}
	$link = mysqli_connect('127.0.0.1', 'root', 'becrespikhtran', 'shop');
	mysqli_set_charset($link, 'utf8');
	
	$fuck = "SELECT `root` FROM `Users` WHERE pseudo='$_SESSION[logged_on_user]'";
	$shit = mysqli_query($link, $fuck);
	
	if (!$shit|| mysqli_num_rows($shit) > 0) 
	{
		$row_user = mysqli_fetch_array($shit);
		if ($row_user['root'] == false)
			{
				echo "Permission Denied";
				exit;
			}


	$name = mysqli_real_escape_string($link, $_POST['name']);
	$image = mysqli_real_escape_string($link,$_POST['image']);
	$price = $_POST['price'];
	$description = mysqli_real_escape_string($link,$_POST['description']);
	
	$query = "SELECT * FROM `Articles` WHERE nom=\"".$name."\"";
	$response = mysqli_query($link, $query);
	
	if (mysqli_num_rows($response) > 0) 
	{
		echo "Error, the article already exist\n";
	
	}
	else 
	{
		if (isset($_POST['tag']) && $_POST['tag'] !== "")
		{
			$array_tag = explode(";",$_POST['tag']);
			foreach ($array_tag as $value)
			{
				$query_tag = "SELECT * FROM Tag WHERE Nom_tag=\"$value\"";
				$response_tag = mysqli_query($link, $query_tag);
				if (mysqli_num_rows($response_tag) < 1) 
				{
					$query_create_tag = "INSERT INTO Tag(Nom_tag) VALUES (\"$value\")";
					mysqli_query($link, $query_create_tag);
					if (mysqli_affected_rows($link) < 1)
						echo "Error fail to create tag $value \n";
				}
			}
		}
		$request = "INSERT INTO `Articles`(`Nom`, `Prix`, `Image`, `Description`) VALUES ('$name', $price, '$image','$description')";
		mysqli_query($link, $request);
		
		if (mysqli_affected_rows($link) == 1) {
			$query_id_article = "SELECT Id_article FROM `Articles`";
			$response_id_article = mysqli_query($link, $query);
			if ($response_id_article)
			{
				$row_id_article = mysqli_fetch_array($response_id_article);
				$id_article = $row_id_article['Id_article'];
			
			if (isset($_POST['tag']) && $_POST['tag'] !== "")
			{
				$array_tag = explode(";",$_POST['tag']);
				foreach ($array_tag as $value)
				{
					$query_get_id_tag = "SELECT Id_tag FROM Tag WHERE Nom_tag='$value'";
					$response_id_tag = mysqli_query($link, $query_get_id_tag);
					if ($response_id_tag)
					{
						$row_id_tag = mysqli_fetch_array($response_id_tag);
						$id_tag = $row_id_tag['Id_tag'];
						
						$query_set_link_tag = "INSERT INTO `Tag_Articles`(`Id_article`, `Id_tag`) VALUES ($id_article,$id_tag)";
						mysqli_query($link, $query_set_link_tag);
						if (mysqli_affected_rows($link) !== 1) {
							echo "Error, can't link : $id_article->id_tag \n";
						}
		}

				}
			echo "Succesfully complete insert !\n";
			exit();
		}echo "Succesfully complete insert !\n";} else {
			echo "Fail to complete insert !\n";
			echo "the query was : <br>\n";
			echo "<h2>$request</h2>";
			var_dump($link);
		}
		
	}}}
	else {
		echo "Error, can't found user";
	}

?>