<?php 

	$link = mysqli_connect('127.0.0.1', 'root', 'becrespikhtran', 'shop');
	mysqli_set_charset($link, 'utf8');
	// 
	
	$query = "SELECT * FROM `Articles`";
	$response = mysqli_query($link, $query);
	if ($response)
	{
		while ($row = mysqli_fetch_array($response))
		{	
			echo "<h1> id = ".$row['ID_article'].", ".$row['Nom']."</h1>";
			echo "<h2>Price = ".(float)$row['Prix']."€</h2>";
			echo "<p>Description : ".$row['Description'];
			echo "<br>";

			$query_2 = "SELECT Id_tag FROM Tag_Articles WHERE Id_article=".$row['ID_article'];
			$response2 = mysqli_query($link, $query_2);
			echo "<p>tag = ";
			while ($row2 = mysqli_fetch_array($response2))
			{
				echo " #".mysqli_fetch_array(mysqli_query($link, "SELECT Nom_tag FROM Tag where Id_tag=".$row2['Id_tag']))['Nom_tag'];

			}
			echo "</p>";
			
			echo "  <img height=auto width=50% src=\"".$row['Image']."\" alt=\"".$row['Nom']."\">";
		}
		// echo "<h1>Query sucess</h1>";
		// print_r($tab);

	}
	else 
		echo "<h1>Query failed</h1>";

?>