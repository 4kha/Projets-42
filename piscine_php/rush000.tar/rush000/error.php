<html>
  <head>
    <meta charset="utf-8">
    <title>Lost in the warp zone</title>
    <link rel="stylesheet" href="index.css">
  </head>
  <body>
    <center><a href="index.php"><img src="img/cat_trotter.png"></a>
  <br/><h1>You are lost in<br/>
    <div> <font size="40">The Warp zone<br/>404</font></h1></center>

  </body>
</html>
