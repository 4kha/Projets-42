<?php
  session_start();
  if ($_PUSH[search] !== 0)
    $search = $_PUSH[search];
  $index = 0;
  $bolean = 0;
  $article1 = array("img"=>"https://68.media.tumblr.com/dc20281ddeb7c96fb9080901bfc33652/tumblr_p420z003Md1qhy6c9o1_1280.gif", "desc"=>"I like", "prix"=>"4.5");
  $article2 = array("img"=>"https://i.pinimg.com/originals/24/f5/1c/24f51c44063429fb51d5f39257fca188.jpg", "desc"=>"Ice cream", "prix"=>"4.5");
  $article3 = array("img"=>"http://38.media.tumblr.com/952b534db2ede6fcf55f2d6e99e7305c/tumblr_njr0p8MKwU1qhy6c9o1_500.gif", "desc"=>"Rondoudoud", "prix"=>"4.5");
  $article4 = array("img"=>"https://i.pinimg.com/originals/e4/c2/34/e4c234002c183c759983da21279ef93e.gif", "desc"=>"valentine", "prix"=>"4.5");

  $tout = array("Chat mignon"=>$article1, "chat glace"=>$article2,
   "chat valentin"=>$article3, "chat rose"=>$article4);
?>

<html>
  <?php include("header.php");?>
  <body>
    <center>
      <table>
    <tr>
<?php foreach ($tout as $elem)
{
  if ($index == 3)
  {
    $index = 0;
    echo "</tr><tr>";
  }
  echo "<td><a href=\"inventory.php\"><img id=\"vignette\"
  src=\"$elem[img]\"/></a>";
  echo "<hov>
  <move class=\"absoright\">$elem[prix]$</move>
  <move class=\"absoleft\">$elem[desc]</move></hov></td>";
  $index++;
}
?>
</tr>
      </table>
    </center>
  </body>
</div>
  <?php include("footer.php");?>
</html>
