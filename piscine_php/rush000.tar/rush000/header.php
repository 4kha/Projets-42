<?php
$open_session = 0;
$panier = 0;

if (isset($_SESSION['logged_on_user']) && $_SESSION['logged_on_user'] != "")
{
  $session = $_SESSION['logged_on_user'];
  if (isset($_SESSION['$panier']))
  {
	  $panier = $_SESSION['panier'];
  }
  else {
	  $panier = "";
  }

  $open_session = 1;
}?>

<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="index.css">
    <title>Rent A Cat - Rent your own cat today !</title>
    <div id="wrap">
      <?php
      if ($open_session == 0)
      echo "<div class=\"login\"><form method=\"POST\" action=\"login.php\">
      Login: <input type=\"text\" name=\"login\" value=\"\">
      Password: <input class=\"smaller_login;\" type=\"password\" name=\"passwd\"value=\"\">
      <input type=\"submit\" name=\"submit\" value=\"OK\"> </div></form>";
      else {
        echo "<div class=\"logged\">Welcome $session</div>";
      }?>
        <div class="panier">
          <?php if ($open_session == 0)
          echo "| <?<a href=\"panier.php\">INSCRIPTION</a>";?>
          |  <a href="error.php">PANIER<?php if ($panier > 0)
          echo "($panier)";?></a>
          |  <a href="error.php">CONTACTER-NOUS</a>
        </div>
	  	<form method="GET" action="inventory.php">
        <div class="search"><input type="submit" name="submit" value="search"/>
          <input type="text" name="search" value="">
		</div>
	</form>

        <a href="index.php"><img id="banner" src="img/cat_banner.jpg"/></a>
        <center><div class="cat_cat">
          <a href="inventory.php?submit=search&search=JustCat"><img class="cat_cat_cat" src="img/cat_justcat.gif" alt="justcat"/></a>
          <a href="inventory.php?submit=search&search=CatFood"><img class="cat_cat_cat" src="img/cat_catfood.gif" alt="catfood"/></a>
          <a href="inventory.php?submit=search&search=MemeCat"><img class="cat_cat_cat" src="img/cat_memecat.gif" alt="memecat"/></a>
          <a href="inventory.php?submit=search&search=NotaCat"><img class="cat_cat_cat" src="img/cat_notcat.gif" alt="notcat"/></a>
        </div></center>
        <hr size="3px" width="70%" color="#DFBD98">
  </head>
<html>
