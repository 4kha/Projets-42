<?php
session_start();
?>
<html>
  <?php include("header.php");?>
  <body>

<center><table width="100%";>
    <tr align="center">
      <td style="width:49%;">
		<form action="insert_data.php" method="post">
			Nom de l'article: <input type="text" name="name"/>
			<br/>
			Lien de l'image: <input type='url' name="image"/>
			<br/>
			Prix:  <input type='number' name="price"/>€
			<br/>
			Decription: <input type='text' name="description"/>
			<br/>
			Tag (separé par ;): <input type="text" name="tag"/>
			<br/>
			<input type="submit" name="submit" value="Ajouter un article">
		</form>
  </td>
        <td style="width:50%;">
          <form class="adm_class" action="insert_data.php" method="post">
            Nom de l'utilisateur <input type="text" name="name"/>
            <br/>
            <input class="adm_ajo" type="submit" name="delete user" value="suprimer un utilisateur">
<br/><br/>
            Nom de l'objet <input type="text" name="name"/>
            <br/>
            <input class="adm_ajo" type="submit" name="delete item" value="suprimer un objet">
          </form>
          </td>
  </tr>
</table></center>
<br/>
  </body>
</div>
  <?php include("footer.php");?>
</html>
