<?php

	if (!isset($_POST['login'])|| !isset($_POST['passwd'])|| $_POST['login'] == null || $_POST['passwd'] == null || $_POST['submit'] !== "OK")
		{
			echo "ERROR\n";
			exit;
		}

	$link = mysqli_connect('127.0.0.1', 'root', 'becrespikhtran', 'shop');
	mysqli_set_charset($link, 'utf8');

	$login = mysqli_real_escape_string($link, $_POST['login']);
	$pass = $_POST['passwd'];

	$query = "SELECT * FROM `Users` WHERE pseudo=\"".$login."\"";
	$response = mysqli_query($link, $query);

	if (mysqli_num_rows($response) > 0) 
	{
		echo "This login is already taking\n";
	}
	else
	{
		$request = "INSERT INTO Users(pseudo, password) VALUES (\"$login\",\"".password_hash($pass, PASSWORD_DEFAULT)."\")";
		mysqli_query($link, $request);

		if (mysqli_affected_rows($link) == 1) {
			echo "Succesfully complete insert !\n";
		} else {
			echo "Fail to complete insert !\n";
			echo "the query was : <br>\n";
			echo "<h2>$request</h2>";
			var_dump($link);
		}
	}
?>
