<?php 

	phpinfo();

?>