<?php
session_start();
if ($_POST[search] !== 0)
  $article1 = $_POST[search];

$article1 = array("img"=>"https://68.media.tumblr.com/dc20281ddeb7c96fb9080901bfc33652/tumblr_p420z003Md1qhy6c9o1_1280.gif", "name"=>"BORDEL DE MERDE", "desc"=>"Le chat le plus mignon de cette planete", "prix"=>"4.5", "tag"=>"chat");

?>
<html>
  <?php include("header.php");?>
  <body>
  <br/>
  <table>
    <tr>
      <td style="width:50%;">
<img id="item" src="<?php echo "$article1[img]";?>"/></td>
  <td style="width:50%;position:relative;">
    <div class="item_title"><?php echo "$article1[name]";?>
  <hr padding-top="0px" size="3px" width="70%" color="#DFBD98"></br>
<div class="item"><?php echo "$article1[desc]";?></div>
</div>

<div class="price"><?php echo "$article1[prix]$";?></div>

  <div><form method="POST" action="buy.php">
  <input class="quant" type="submit" name="BUY" value="Ajouter au panier"> </div></form>
<div class="tag"><?php echo "Categorie:$article1[tag]";?>
</div></td></tr>
    </table>
  </body>
</div>
  <?php include("footer.php");?>
</html>
