<?php
session_start();
?>
<html>
  <?php include("header.php");?>
  <body>
    <br/>
<center><form name="passwd" action="create.php" method="post">
	Identifiant: <input type="text" name="login"/>
	<br/>
	Mot de passe: <input type="password" name="passwd"/>
	<br/>
	Validation: <input type="password" name="passwd_check"/>
	<br/>
	<input type="submit" name="submit" value="OK">
  <br/><center><br/>
    </body>

  </div>
  <?php include("footer.php");?>
</html>
