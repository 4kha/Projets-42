<html>
<div id="footer">
  <br/>
    <footer class="trotter">
      <hr size="3px" width="100%" color="#DFBD98"></br>
      <center><img id="trotter_cat" src="img/cat_trotter.png"/><br/>
      <div class="info">
        <a href="error.php">Qui sommes-nous</a> -
        <a href="error.php">Boutiques</a> -
        <a href="error.php">Paiement sécurisé</a> -
        <a href="error.php">Mentions légales</a> -
        <a href="error.php">CGV</a> -
        <a href="error.php">Echanges et Retours</a> -
        <a href="error.php">Livraisons</a> -
        <a href="error.php">Contact</a><br/>
      <div class="copyright"><i>© Hitler cat, was right reserved</i></div></div></center>
    </footer>
  </div>
</html>
